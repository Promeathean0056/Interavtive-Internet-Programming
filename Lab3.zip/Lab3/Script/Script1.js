// JavaScript source code

var salesperson = ["Brad", "Nila", "Joseph", "Kesh", "Lydia", "Devon", "Miller"];
var decsales = [1500, 15000, 30000, 12000, 45000, 25000, 8000];
var jansales = [10000, 25000, 20000, 14000, 30000, 16000, 30000];
var febsales = [8000, 7500, 45000, 10000, 38000, 22000, 15000];



var person = 0;
var i = 0;
var Sum;
var comm;
var totalcomm = 0;
var avgcomm;
var topcomm = 0;
while (i < salesperson.length)
{
	Sum = decsales[person] + jansales[person] + febsales[person];
	console.log(salesperson[person] + " made: $" + Sum + " over the past three months");
	if (Sum > 30000)
{
	comm = Sum * 0.08;
}
if (Sum > 15000)
{
	comm = Sum * 0.05;
}
if (Sum > 10000)
{
	comm = Sum * 0.03;
}
if (Sum > 5000)
{
	comm = Sum * 0.02;
}
if (Sum > 0)
{
	comm = Sum * 0.01;
}
else
{
	console.log("SOMETHING WENT WRONG!")
}

totalcomm = totalcomm + comm;

avgcomm = totalcomm / 3;

console.log(salesperson[person] + " commission price is " + comm + " and the average commision price is " + avgcomm);

if (comm > topcomm)
{
	topcomm = comm;
}
i++;
person++;
}
console.log("the top commission is $" + topcomm);