//JQ DOM Traversal
//$("") will be used as a frame of reference
   //parent()
   //parents()
   //find()
   //siblings()
   //children()
   
    //Additional Sibling methods 
    //next
    //nextAll
    //nextUntil   
     
   //prev
   //prevAll
   //prevUntil
    
   //closest
   
   
   //first
   //last
   //filter
   //not   
   //slice


$(function(){  //$(document).ready(function(){})
    
   console.log("hello");
   $("#button1").on("click",function(){
      $("#content").parent().css("background-color","purple");      
   });

   $("#button2").on("click",function(){
      $("#content").parents().css("font-size","1.6em");
   });

   $("#button3").on("click",function(){
      $("#content").parentsUntil("#1").css("border","solid 1px red");
   });

   $("#button4").on("click",function(){
      console.log($("#container").children().length);
   });

   $("#button5").on("click",function(){
      $("#content").siblings().css("color","green");
   });

   $("#button6").on("click",function(){
      var descendants = $("#content").find("p");//* means all descendants
      descendants.each(function(){
         console.log($(this).html());
      });
   });
   $("#button7").on("click",function(){
      var next = $("#content").next();
	  console.log($(this).html("the next sibling is " + next));
   });
   $("#button8").on("click",function(){
      var prev = $("#content").prev();
	  console.log($(this).html("the previous sibling is " + prev));
   });
   $("#button9").on("click",function(){
      var closest = $("#content").closest();
	  console.log($(this).html("the closest sibling is " + closest));
   });
   $("#button10").on("click",function(){
      var f = $("#content").first();
	  console.log($(this).html("the first sibling is " + f));
   });
   $("#button11").on("click",function(){
      var l = $("#content").last();
	  console.log($(this).html("the last sibling is " + l));
   });
   $("#button12").on("click",function(){
      $("#content").filter(){
	  
	  }
   });
   $("#button13").on("click",function(){
      $("#content").not();
	  
   });
   $("#button14").on("click",function(){
      $("#content").slice();
	  
   });
})

