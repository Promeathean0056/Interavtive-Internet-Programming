// JavaScript source code


function Toggle() {
var tog = document.getElementById("wrapper");
	if (tog.style.display == "none") {
		tog.style.display = "block";
	}
	else {
		tog.style.display = "none";
	}
	function Chess() {
		console.log("Activated");
	}
}